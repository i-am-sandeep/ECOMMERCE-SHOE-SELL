package com.example.shoesecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoesEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
